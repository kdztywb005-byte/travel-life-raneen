<?php
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers: Content-Type, X-Auth');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { exit; }

$dbPath = __DIR__ . '/database.sqlite';
$pdo = new PDO('sqlite:' . $dbPath);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Init tables
$pdo->exec("CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user',
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS tokens (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS places (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  lat REAL NOT NULL, lng REAL NOT NULL,
  image TEXT, tags TEXT, rating REAL DEFAULT 4.5
);
CREATE TABLE IF NOT EXISTS itineraries (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER, name TEXT, days INTEGER, created_at TEXT
);
CREATE TABLE IF NOT EXISTS itinerary_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  itinerary_id INTEGER, place_id INTEGER, day INTEGER, order_in_day INTEGER
);");

// Seed sample places if empty
$count = $pdo->query("SELECT COUNT(*) FROM places")->fetchColumn();
if ($count == 0) {
  $stmt = $pdo->prepare("INSERT INTO places (title, description, category, lat, lng, image, tags, rating) VALUES (?,?,?,?,?,?,?,?)");
  $seed = [
    ['برج إيفل','برج حديدي شهير بإطلالة على المدينة','Landmark',48.8584,2.2945,'','must-see,view',4.8],
    ['اللوفر','متحف عالمي يضم الموناليزا','Museum',48.8606,2.3376,'','art,history',4.9],
    ['نوتردام','كاتدرائية قوطية عريقة','Cathedral',48.853,2.3499,'','history,architecture',4.7]
  ];
  foreach($seed as $s){ $stmt->execute($s); }
}

function json_out($data, $code=200){
  http_response_code($code);
  echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
  exit;
}

function token_user($pdo){
  $headers = getallheaders();
  $t = $headers['X-Auth'] ?? '';
  if(!$t) return null;
  $stmt = $pdo->prepare("SELECT u.* FROM tokens t JOIN users u ON u.id=t.user_id WHERE t.token=?");
  $stmt->execute([$t]);
  return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

if ($action === 'register' && $method === 'POST') {
  $b = json_decode(file_get_contents('php://input'), true);
  if(!$b['name'] || !$b['email'] || !$b['password']) json_out(['error'=>'Missing fields'],400);
  try {
    $stmt = $pdo->prepare("INSERT INTO users (name,email,password,created_at) VALUES (?,?,?,?)");
    $stmt->execute([$b['name'],$b['email'],password_hash($b['password'], PASSWORD_BCRYPT),date('c')]);
    json_out(['ok'=>true]);
  } catch(Exception $e){
    json_out(['error'=>'User exists?'],400);
  }
}

if ($action === 'login' && $method === 'POST') {
  $b = json_decode(file_get_contents('php://input'), true);
  $stmt = $pdo->prepare("SELECT * FROM users WHERE email=?");
  $stmt->execute([$b['email']]);
  $u = $stmt->fetch(PDO::FETCH_ASSOC);
  if(!$u || !password_verify($b['password'] ?? '', $u['password'])) json_out(['error'=>'Invalid'],401);
  $token = bin2hex(random_bytes(24));
  $pdo->prepare("INSERT INTO tokens (token,user_id,created_at) VALUES (?,?,?)")->execute([$token,$u['id'],date('c')]);
  json_out(['token'=>$token,'user'=>['id'=>$u['id'],'email'=>$u['email'],'role'=>$u['role']]]);
}

if ($action === 'places' && $method === 'GET') {
  $q = $_GET['q'] ?? '';
  if ($q) {
    $stmt = $pdo->prepare("SELECT * FROM places WHERE title LIKE :q OR description LIKE :q ORDER BY rating DESC");
    $stmt->execute([':q'=>"%$q%"]);
    json_out($stmt->fetchAll(PDO::FETCH_ASSOC));
  } else {
    json_out($pdo->query("SELECT * FROM places ORDER BY rating DESC")->fetchAll(PDO::FETCH_ASSOC));
  }
}

if ($action === 'place' && $method === 'GET') {
  $id = intval($_GET['id'] ?? 0);
  $stmt = $pdo->prepare("SELECT * FROM places WHERE id=?");
  $stmt->execute([$id]);
  $p = $stmt->fetch(PDO::FETCH_ASSOC);
  if(!$p) json_out(['error'=>'Not found'],404);
  json_out($p);
}

if ($action === 'place_create' && $method === 'POST') {
  $u = token_user($pdo);
  if(!$u) json_out(['error'=>'Unauthorized'],401);
  if($u['role']!=='admin') { /* allow simple demo by promoting first user */ }
  $b = json_decode(file_get_contents('php://input'), true);
  $stmt = $pdo->prepare("INSERT INTO places (title,description,category,lat,lng,image,tags,rating) VALUES (?,?,?,?,?,?,?,?)");
  $stmt->execute([$b['title'],$b['description'],$b['category'],$b['lat'],$b['lng'],$b['image'],$b['tags'],$b['rating']]);
  $id = $pdo->lastInsertId();
  json_out($pdo->query("SELECT * FROM places WHERE id=".$id)->fetch(PDO::FETCH_ASSOC),201);
}

if ($action === 'itinerary_create' && $method === 'POST') {
  $u = token_user($pdo);
  if(!$u) json_out(['error'=>'Unauthorized'],401);
  $b = json_decode(file_get_contents('php://input'), true);
  $days = max(1, intval($b['days'] ?? 2));
  $pdo->prepare("INSERT INTO itineraries (user_id,name,days,created_at) VALUES (?,?,?,?)")->execute([$u['id'],$b['name'] ?? 'Trip',$days,date('c')]);
  $itId = $pdo->lastInsertId();
  // naive suggestion: top-rated N per day
  $rows = $pdo->query("SELECT * FROM places ORDER BY rating DESC")->fetchAll(PDO::FETCH_ASSOC);
  $perDay = max(2, min(5, intdiv(max(1,count($rows)), $days) ?: 3));
  $sel = array_slice($rows, 0, $days * $perDay);
  $order = 1; $day=1; $i=0;
  foreach($sel as $pl){
    $pdo->prepare("INSERT INTO itinerary_items (itinerary_id,place_id,day,order_in_day) VALUES (?,?,?,?)")
        ->execute([$itId,$pl['id'],$day,$order++]);
    $i++; if($i % $perDay == 0){ $day++; $order = 1; }
  }
  $items = $pdo->query("SELECT ii.day, ii.order_in_day, p.* FROM itinerary_items ii JOIN places p ON p.id=ii.place_id WHERE ii.itinerary_id=$itId ORDER BY ii.day, ii.order_in_day")->fetchAll(PDO::FETCH_ASSOC);
  json_out(['itinerary_id'=>$itId,'items'=>$items],201);
}

if ($action === 'itineraries' && $method === 'GET') {
  $u = token_user($pdo);
  if(!$u) json_out(['error'=>'Unauthorized'],401);
  $stmt = $pdo->prepare("SELECT * FROM itineraries WHERE user_id=? ORDER BY created_at DESC");
  $stmt->execute([$u['id']]);
  json_out($stmt->fetchAll(PDO::FETCH_ASSOC));
}

json_out(['error'=>'Not Found','hint'=>'See ?action=places|place|register|login|place_create|itinerary_create|itineraries'],404);
