
import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import App from './App.jsx'
import Home from './pages/Home.jsx'
import Planner from './pages/Planner.jsx'
import Details from './pages/Details.jsx'

createRoot(document.getElementById('root')).render(
  <BrowserRouter>
    <Routes>
      <Route element={<App />}>
        <Route path="/" element={<Home />} />
        <Route path="/planner" element={<Planner />} />
        <Route path="/attraction/:id" element={<Details />} />
      </Route>
    </Routes>
  </BrowserRouter>
)
