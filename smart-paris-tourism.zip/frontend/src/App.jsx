
import React, { useState, useMemo } from 'react'
import { Outlet, Link, useLocation } from 'react-router-dom'

export const LangContext = React.createContext({ lang: 'ar', setLang: () => {} })

export default function App() {
  const [lang, setLang] = useState('ar')
  const location = useLocation()
  const t = useMemo(() => dict[lang], [lang])

  return (
    <LangContext.Provider value={{ lang, setLang }}>
      <header className="header">
        <nav className="nav">
          <Link to="/"><strong>Smart Paris</strong></Link>
          <Link to="/planner">{t.planner}</Link>
        </nav>
        <button className="lang-toggle" onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')}>
          {lang === 'ar' ? 'English' : 'العربية'}
        </button>
      </header>
      <div className="container">
        <Outlet context={{ t }} />
      </div>
      <div className="footer">© {new Date().getFullYear()} Smart Paris Tourism</div>
    </LangContext.Provider>
  )
}

const dict = {
  ar: { search:'ابحث عن مكان...', category:'الفئة', all:'الكل', planner:'مخطط الرحلة', viewOnMap:'عرض على الخريطة', price:'السعر', hours:'الساعات', details:'التفاصيل', suggestPlan:'اقتراح خطة', interests:'الاهتمامات', days:'الأيام', generate:'توليد الخطة', itinerary:'البرنامج المقترح', rating:'التقييم' },
  en: { search:'Search place...', category:'Category', all:'All', planner:'Trip Planner', viewOnMap:'View on map', price:'Price', hours:'Hours', details:'Details', suggestPlan:'Suggest Plan', interests:'Interests', days:'Days', generate:'Generate', itinerary:'Suggested Itinerary', rating:'Rating' }
}
