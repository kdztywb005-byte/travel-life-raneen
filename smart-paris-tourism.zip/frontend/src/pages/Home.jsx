
import React, { useContext, useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import L from 'leaflet'
import { LangContext } from '../App.jsx'

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000'

export default function Home() {
  const { lang } = useContext(LangContext)
  const [q, setQ] = useState('')
  const [category, setCategory] = useState('')
  const [list, setList] = useState([])

  const fetchData = async () => {
    const url = new URL(`${API}/api/attractions`)
    if (q) url.searchParams.set('q', q)
    if (category) url.searchParams.set('category', category)
    url.searchParams.set('lang', lang)
    const r = await fetch(url)
    const j = await r.json()
    setList(j)
  }

  useEffect(() => { fetchData() }, [lang])
  const pos = [48.8566, 2.3522]

  // simple default icon fix for leaflet in Vite
  delete L.Icon.Default.prototype._getIconUrl;
  L.Icon.Default.mergeOptions({
    iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
    iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
    shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  });

  const t = lang === 'ar' ? dict.ar : dict.en

  return (
    <div className="grid">
      <div className="card">
        <h1>Smart Paris</h1>
        <p className="small">{lang === 'ar' ? 'اكتشف باريس بخطة ذكية ومخصصة لاهتماماتك.' : 'Discover Paris with a smart, personalized plan.'}</p>
        <div style={{display:'grid', gridTemplateColumns:'1fr 180px 120px', gap:12, marginTop:12}}>
          <input className="input" placeholder={t.search} value={q} onChange={e => setQ(e.target.value)} />
          <select className="select" value={category} onChange={e => setCategory(e.target.value)}>
            <option value="">{t.all}</option>
            <option value="landmark">{lang==='ar'?'معالم':'Landmark'}</option>
            <option value="museum">{lang==='ar'?'متحف':'Museum'}</option>
            <option value="shopping">{lang==='ar'?'تسوق':'Shopping'}</option>
            <option value="park">{lang==='ar'?'حديقة':'Park'}</option>
            <option value="heritage">{lang==='ar'?'تراث':'Heritage'}</option>
            <option value="river">{lang==='ar'?'نهر':'River'}</option>
            <option value="theme">{lang==='ar'?'تِرفيه':'Theme'}</option>
          </select>
          <button className="button" onClick={fetchData}>{lang==='ar'?'بحث':'Search'}</button>
        </div>
        <div className="list" style={{marginTop:16}}>
          {list.map(item => (
            <div key={item.id} className="card">
              <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                <div>
                  <h3>{item.name} <span className="badge">{item.category}</span></h3>
                  <div className="small">{t.rating}: {item.rating?.toFixed(1) ?? '-'}</div>
                </div>
                <Link className="button" to={`/attraction/${item.id}`}>{t.details}</Link>
              </div>
              <p className="small">{item.description}</p>
              <div className="small">{t.hours}: {item.hours} · {t.price}: {item.price}€</div>
            </div>
          ))}
        </div>
      </div>
      <div className="card">
        <MapContainer center={pos} zoom={12} scrollWheelZoom={false}>
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          {list.map(item => (
            <Marker key={item.id} position={[item.lat, item.lng]}>
              <Popup>
                <strong>{item.name}</strong><br />
                {item.category}<br />
                <Link to={`/attraction/${item.id}`}>{t.details}</Link>
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
    </div>
  )
}

const dict = { ar:{ all:'الكل', search:'ابحث...', details:'التفاصيل', hours:'الساعات', price:'السعر', rating:'التقييم' }, en:{ all:'All', search:'Search...', details:'Details', hours:'Hours', price:'Price', rating:'Rating' } }
