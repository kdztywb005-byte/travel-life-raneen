
import React, { useContext, useState } from 'react'
import { LangContext } from '../App.jsx'

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000'

export default function Planner() {
  const { lang } = useContext(LangContext)
  const [days, setDays] = useState(3)
  const [interests, setInterests] = useState(['history','views'])
  const [plan, setPlan] = useState(null)

  const toggle = (v) => {
    setInterests(x => x.includes(v) ? x.filter(i => i!==v) : [...x, v])
  }

  const generate = async () => {
    const url = new URL(`${API}/api/trips/suggest`)
    url.searchParams.set('days', days)
    url.searchParams.set('interests', interests.join(','))
    url.searchParams.set('lang', lang)
    const r = await fetch(url)
    const j = await r.json()
    setPlan(j)
  }

  const t = lang === 'ar' ? dict.ar : dict.en

  return (
    <div className="card">
      <h2>{t.title}</h2>
      <div className="small">{t.subtitle}</div>
      <div style={{display:'flex', gap:12, flexWrap:'wrap', marginTop:12}}>
        {['history','art','shopping','family','views','romance'].map(v => (
          <label key={v} className="button">
            <input type="checkbox" checked={interests.includes(v)} onChange={() => toggle(v)} /> {' '}
            {t[v]}
          </label>
        ))}
        <div style={{marginInlineStart:'auto'}}>
          {t.days}: <input className="input" type="number" min="1" max="7" value={days} onChange={e=>setDays(e.target.value)} style={{width:80, display:'inline-block'}} />
          <button className="button" onClick={generate} style={{marginInlineStart:8}}>{t.generate}</button>
        </div>
      </div>

      {plan && (
        <div style={{marginTop:16}}>
          <h3>{t.itinerary}</h3>
          {plan.itinerary.map(d => (
            <div key={d.day} className="card">
              <strong>{t.day} {d.day}</strong>
              <ul>
                {d.items.map(it => (
                  <li key={it.id} className="small">• {it.name} ({it.category}) — {t.hours}: {it.hours} — {t.price}: {it.price}€</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

const dict = {
  ar: { title:'مخطط الرحلة الذكي', subtitle:'اختر اهتماماتك وعدد الأيام لنقترح لك برنامجًا مناسبًا.', history:'تاريخ', art:'فن', shopping:'تسوق', family:'عائلة', views:'مناظر', romance:'رومانسية', days:'الأيام', generate:'توليد الخطة', itinerary:'البرنامج المقترح', day:'اليوم', hours:'الساعات', price:'السعر' },
  en: { title:'Smart Trip Planner', subtitle:'Choose your interests and trip length to get a tailored plan.', history:'History', art:'Art', shopping:'Shopping', family:'Family', views:'Views', romance:'Romance', days:'Days', generate:'Generate', itinerary:'Suggested Itinerary', day:'Day', hours:'Hours', price:'Price' }
}
