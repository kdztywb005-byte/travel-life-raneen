
import React, { useContext, useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { LangContext } from '../App.jsx'

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000'

export default function Details() {
  const { id } = useParams()
  const { lang } = useContext(LangContext)
  const [item, setItem] = useState(null)
  const [weather, setWeather] = useState(null)

  useEffect(() => {
    const run = async () => {
      const u = new URL(`${API}/api/attractions/${id}`)
      u.searchParams.set('lang', lang)
      const r = await fetch(u); const j = await r.json(); setItem(j)
      const w = await fetch(`${API}/api/weather?city=Paris`); const wj = await w.json(); setWeather(wj)
    }
    run()
  }, [id, lang])

  if (!item) return <div className="card">Loading...</div>
  return (
    <div className="card">
      <h2>{item.name}</h2>
      <div className="small">{item.category} · {item.rating?.toFixed(1) ?? '-'}</div>
      <p className="small">{item.description}</p>
      <div className="small">Hours: {item.hours} · Price: {item.price}€</div>
      {weather && <div className="badge">{weather.city}: {weather.tempC}°C — {weather.description}</div>}
    </div>
  )
}
