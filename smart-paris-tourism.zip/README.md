
# Smart Tourism & Travel in Paris (Full-Stack)

مشروع جاهز (Front-End + Back-End) لبناء تطبيق سياحي ذكي في باريس.

## المتطلبات
- Node.js 18+
- اتصال إنترنت (لازم فقط لخرائط OpenStreetMap واختيارياً للطقس)
- منفذ 4000 للباك و 5173 للفرونت

## طريقة التشغيل (خطوة بخطوة)
1) فك ضغط الملف.
2) افتح نافذتين (Terminal):
   - النافذة الأولى: تشغيل الباك إند
     ```bash
     cd backend
     cp .env.example .env   # اختياري: ضع OWM_API_KEY إن توفر
     npm install
     npm run dev
     ```
     سيعمل على: http://localhost:4000
   - النافذة الثانية: تشغيل الفرونت إند
     ```bash
     cd frontend
     npm install
     npm run dev
     ```
     سيفتح على: http://localhost:5173

> إن رغبت بملف .env للفرونت، أنشئ `frontend/.env` وضع فيه:
```
VITE_API_URL=http://localhost:4000
```

## نقاط رئيسية
- **/api/attractions**: جلب قائمة المعالم (بحث/فئة/لغة).
- **/api/attractions/:id**: تفاصيل معلم.
- **/api/trips/suggest**: اقتراح برنامج رحلة ذكي (days/interests/lang).
- **/api/bookings [POST]**: إنشاء حجز (حاليًا يحفظ في ملف JSON).
- **/api/weather**: طقس بسيط (يستخدم OpenWeatherMap إذا وضعت مفتاحًا).

## تعديل البيانات
- ملف المعالم: `backend/data/attractions.json` — أضف/عدل معالم باريس.
- الحجوزات تحفظ في: `backend/data/bookings.json`.

## نشر سريع
- يمكنك نشر الباك على Render/railway.
- ونشر الفرونت على Netlify/Vercel وتعيين `VITE_API_URL` إلى عنوان الباك.

## ملاحظات
- الخريطة تستخدم OpenStreetMap عبر Leaflet بدون مفاتيح.
- الواجهة ثنائية اللغة (عربي/English) بزر تبديل.
- الكود مرتب وبسيط للتوسع (إضافة مصادقة JWT، قاعدة بيانات MongoDB، دفع Stripe لاحقًا).
