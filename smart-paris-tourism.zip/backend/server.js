
const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const morgan = require('morgan');
const dotenv = require('dotenv');
const { nanoid } = require('nanoid');
const Joi = require('joi');
let fetch = undefined;
try { fetch = require('node-fetch'); } catch (e) {}

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));

const DATA_DIR = path.join(__dirname, 'data');
const ATTRACTIONS_FILE = path.join(DATA_DIR, 'attractions.json');
const BOOKINGS_FILE = path.join(DATA_DIR, 'bookings.json');

function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) {
    return fallback;
  }
}
function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
}

// initialize files if not exist
if (!fs.existsSync(BOOKINGS_FILE)) writeJson(BOOKINGS_FILE, []);

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'smart-paris-backend', time: new Date().toISOString() });
});

app.get('/api/attractions', (req, res) => {
  const q = (req.query.q || '').toLowerCase();
  const category = (req.query.category || '').toLowerCase();
  const lang = (req.query.lang || 'ar').toLowerCase();
  const data = readJson(ATTRACTIONS_FILE, []);
  let result = data.filter(item => {
    const name = ((lang === 'en') ? item.name_en : item.name_ar) || '';
    const desc = ((lang === 'en') ? item.description_en : item.description_ar) || '';
    const matchesQ = !q || name.toLowerCase().includes(q) || desc.toLowerCase().includes(q);
    const matchesCat = !category || (item.category && item.category.toLowerCase() === category);
    return matchesQ && matchesCat;
  });
  result = result.sort((a,b) => (b.rating || 0) - (a.rating || 0));
  // map language fields
  result = result.map(item => ({
    id: item.id,
    name: (lang === 'en') ? item.name_en : item.name_ar,
    description: (lang === 'en') ? item.description_en : item.description_ar,
    category: item.category,
    lat: item.lat, lng: item.lng,
    price: item.price, hours: item.hours, rating: item.rating, images: item.images || []
  }));
  res.json(result);
});

app.get('/api/attractions/:id', (req, res) => {
  const lang = (req.query.lang || 'ar').toLowerCase();
  const data = readJson(ATTRACTIONS_FILE, []);
  const found = data.find(x => x.id === req.params.id);
  if (!found) return res.status(404).json({ error: 'Not found' });
  const resp = {
    id: found.id,
    name: (lang === 'en') ? found.name_en : found.name_ar,
    description: (lang === 'en') ? found.description_en : found.description_ar,
    category: found.category,
    lat: found.lat, lng: found.lng,
    price: found.price, hours: found.hours, rating: found.rating, images: found.images || []
  };
  res.json(resp);
});

// simple rule-based trip suggestion
app.get('/api/trips/suggest', (req, res) => {
  const days = Math.max(1, Math.min(parseInt(req.query.days || '1', 10), 7));
  const interests = (req.query.interests || '').toLowerCase().split(',').map(s => s.trim()).filter(Boolean);
  const lang = (req.query.lang || 'ar').toLowerCase();
  const data = readJson(ATTRACTIONS_FILE, []);
  // map simple categories -> interests
  const interestMap = {
    history: ['museum', 'landmark', 'heritage'],
    art: ['museum', 'gallery'],
    shopping: ['shopping', 'market'],
    family: ['park', 'theme'],
    views: ['landmark', 'tower', 'river'],
    romance: ['landmark', 'river', 'view']
  };
  let filtered = data.slice();
  if (interests.length) {
    filtered = data.filter(item => {
      const cat = (item.category || '').toLowerCase();
      return interests.some(i => (interestMap[i] || []).includes(cat) || cat.includes(i));
    });
  }
  filtered = filtered.sort((a,b) => (b.rating || 0) - (a.rating || 0));
  // chunk into days
  const perDay = Math.max(2, Math.min(5, Math.ceil(filtered.length / days)));
  const itinerary = [];
  for (let d=0; d<days; d++) {
    const start = d*perDay;
    const slice = filtered.slice(start, start+perDay);
    itinerary.push({
      day: d+1,
      items: slice.map(it => ({
        id: it.id,
        name: (lang === 'en') ? it.name_en : it.name_ar,
        category: it.category,
        lat: it.lat, lng: it.lng,
        hours: it.hours, price: it.price, rating: it.rating
      }))
    });
  }
  res.json({ days, interests, itinerary });
});

const bookingSchema = Joi.object({
  userName: Joi.string().min(2).required(),
  email: Joi.string().email().required(),
  items: Joi.array().items(Joi.object({
    type: Joi.string().valid('attraction','hotel','restaurant','transport').required(),
    id: Joi.string().required(),
    date: Joi.string().required()
  })).min(1).required(),
  total: Joi.number().min(0).required()
});

app.post('/api/bookings', (req, res) => {
  const { error, value } = bookingSchema.validate(req.body, { abortEarly: false });
  if (error) return res.status(400).json({ error: 'Validation failed', details: error.details });
  const bookings = readJson(BOOKINGS_FILE, []);
  const record = { id: nanoid(10), ...value, createdAt: new Date().toISOString() };
  bookings.push(record);
  writeJson(BOOKINGS_FILE, bookings);
  res.status(201).json({ ok: true, booking: record });
});

// optional weather proxy (requires OWM_API_KEY)
app.get('/api/weather', async (req, res) => {
  const city = (req.query.city || 'Paris');
  const key = process.env.OWM_API_KEY;
  if (!key || !fetch) {
    return res.json({ note: 'Set OWM_API_KEY to get live weather', city, tempC: 24, description: 'Clear (sample)' });
  }
  try {
    const r = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(city)}&appid=${key}&units=metric`);
    const j = await r.json();
    res.json({ city: j.name, tempC: j.main?.temp, description: j.weather?.[0]?.description });
  } catch (e) {
    res.status(500).json({ error: 'Weather fetch failed', details: String(e) });
  }
});

app.listen(PORT, () => {
  console.log(`Smart Paris backend running on http://localhost:${PORT}`);
});
